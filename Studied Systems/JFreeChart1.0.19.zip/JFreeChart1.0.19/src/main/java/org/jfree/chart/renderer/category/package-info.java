/**
 * Plug-in renderers for the {@link org.jfree.chart.plot.CategoryPlot} class.
 */
package org.jfree.chart.renderer.category;
