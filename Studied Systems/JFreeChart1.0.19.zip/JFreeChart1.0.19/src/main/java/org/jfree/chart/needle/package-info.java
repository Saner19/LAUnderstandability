/**
 * A range of objects that can be used to represent the needle on a
 * {@link org.jfree.chart.plot.CompassPlot}.
 */
package org.jfree.chart.needle;
