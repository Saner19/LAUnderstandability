/**
 * Core classes, including {@link org.jfree.chart.JFreeChart} and
 * {@link org.jfree.chart.ChartPanel}.
 */
package org.jfree.chart;
