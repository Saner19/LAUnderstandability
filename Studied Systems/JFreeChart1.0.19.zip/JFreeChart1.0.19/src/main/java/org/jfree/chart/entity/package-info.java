/**
 * Classes representing components of (or entities in) a chart.
 */
package org.jfree.chart.entity;
