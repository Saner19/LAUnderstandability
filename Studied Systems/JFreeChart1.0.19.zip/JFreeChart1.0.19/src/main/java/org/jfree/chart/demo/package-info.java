/**
 * Some basic demos to get you started.  A large range of demo applications is
 * available for download (including source code) with the JFreeChart Developer
 * Guide.  For more information, see:
 * <p>
 * <a href="http://www.object-refinery.com/jfreechart/guide.html" target="_blank">
 * http://www.object-refinery.com/jfreechart/guide.html
 * </a>
 */
package org.jfree.chart.demo;
