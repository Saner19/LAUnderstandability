/**
 * Localised resources for the JFreeChart class library.
 */
package org.jfree.chart.resources;
