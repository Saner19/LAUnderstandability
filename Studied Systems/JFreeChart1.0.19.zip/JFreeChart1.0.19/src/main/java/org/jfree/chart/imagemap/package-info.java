/**
 * Classes, including {@link org.jfree.chart.imagemap.ImageMapUtilities}, for creating HTML image maps.
 */
package org.jfree.chart.imagemap;
